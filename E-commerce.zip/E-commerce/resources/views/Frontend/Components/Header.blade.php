{{-- <!-=== Header start ===--> --}}
<section class="header fixed-top">
  <div>
      <p>WELCOME TO BANGLADESHI ONLINE STORE</p>
  </div>
  <ul>
      <li><a href=""><i class="fa-solid fa-location-dot icon"></i> Store Locator</a></li>
      <li><a href=""><i class="fa-solid fa-truck icon"></i> Track Your Order</a></li>
      <li><a href=""><i class="fa-solid fa-cart-shopping icon"></i> Shop</a></li>
      <li><a href=""><i class="fa-regular fa-user icon"></i> My Account</a></li>
  </ul>
</section>
{{-- <!-=== Header end ===--> --}}