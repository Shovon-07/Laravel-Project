<div class="popup hidePopUp" id="editPopUp">
    <div style="color:yellow; font-size:20px">
        <h2>Edit !</h2>
    </div>
    <div>
        <input type="text" class="editAbleItem">
        <input type="text" id="categoryName" placeholder="Category name" style="margin-top: 20px">
        
    </div>
    <button id="closePopUp" onclick="editeCategory()">CONFIRM</button>
    <a class="cancel" id="closePopUp" onclick="closePopUp()">Cancel</a>
</div>

<script>
    function editeCategory() {
        const categoryId = document.querySelector(".editAbleItem").value;
        const categoryName = document.querySelector("#categoryName").value;

        if(categoryName.length === 0) {
            showTost("Please enter category name");
        } else {
            
            showTost(categoryId);
        }
    }
</script><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Components/CategoryEdit.blade.php ENDPATH**/ ?>