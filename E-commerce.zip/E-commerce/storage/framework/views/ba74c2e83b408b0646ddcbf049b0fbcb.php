<div>
    <table>
        <thead>
            <tr>
                <th>Sl</th>
                <th>Name</th>
                <th>Roll</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="tableData">
            
        </tbody>
    </table>

    <div class="paginate">
        <button class="next">Next</button> <span></span>
        <button class="prev">Prev</button>
    </div>
</div>

<script>
    let tableData = document.querySelector('#tableData');
    tableData.innerHTML = `<tr>
                <td>1</td>
                <td>Shovon</td>
                <td>520</td>
                <td>shovon@gmail.com</td>
                <td>01931</td>
                <td>image</td>
                <td>
                    <button class="edite">Edite</button> <span class="btnDevider">|</span>
                    <button class="delete">Delete</button>
                </td>
            </tr>`
</script>
<?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Components/Table.blade.php ENDPATH**/ ?>