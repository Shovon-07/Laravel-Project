<title>Sign In</title>

<?php $__env->startSection('content'); ?>
    

<div class="form-container">
    <div class="form">
        <h4 class="title">SIGN IN</h4>
        <div>
            <input type="email" id="email" placeholder="Enter your email address">
        </div>
        <div>
            <input type="password" id="password" autocomplete="off" placeholder="Enter your password">
        </div>
        <div class="buttonDiv">
             <button type="submit" class="button" id="login" onclick="login()">NEXT</button>
        </div>
            <div class="formBottom">
            <a href="<?php echo e(route('signup.view')); ?>">Sign Up</a> <span>|</span> <a href="<?php echo e(route('forgotpass.view')); ?>">Forgot password</a>
        </div>
    </div>
</div>

<script>
    async function login() {
        const email = document.querySelector("#email").value;
        const password = document.querySelector("#password").value;

        if(email.length === 0) {
            showTost("Please enter email address");
        } else if(password.length < 3) {
            showTost("Please enter a strong password minimum 3 cherecter");
        } else if(password.length > 6) {
            showTost("Please enter a strong password maximum 6 cherecter");
        } else {
            // alert(email + " " + password)
            showLoader();
            const response = await axios.post("/admin/login", {
                "email" : email,
                "password" : password
            });
            hideLoader();

            if(response.data['status'] === 'success') {
                showTost(response.data['message']);
                setToken(response.data['token']);
                setTimeout(() => {
                    window.location.href = "/admin/dashboard";
                }, 1000);
            } else {
                showTost(response.data['message']);
            }
        }

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.Links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Auth/Login.blade.php ENDPATH**/ ?>