<footer class="footer">
    <h3>All rights reserved by <strong>Shovon</strong></h3>
</footer>