<title>update profile</title>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('Backend.Components.ChangeProfilePicPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="form-container d-flex" style="margin: 50px 0">
        
        <div class="form">
            <h4 class="title">PROFILE</h4>
            <div class="userImgContainer overlay" onclick="showPopUp()">
                <img class="userImg" id="userImg">
                <i class="fa-solid fa-share-from-square shareIcon"></i>
            </div>
                    <div>
                        <input type="text" id="name" placeholder="User name">
                    </div>
                    <div>
                        <input type="email" readonly id="email" placeholder="User email">
                    </div>
                    <div>
                        <input type="password" id="password" autocomplete="off" placeholder="Password">
                    </div>
            <div class="buttonDiv">
                <button type="submit" class="button" onclick="updateProfile()">UPDATE</button>
            </div>
        </div>
    </div>

    <script>
        let name = document.querySelector("#name");
        let email = document.querySelector("#email");
        let password = document.querySelector("#password");

        window.addEventListener('load', () => {
            userData();
        });

        async function userData() {
            showLoader();
            const response = await axios.get("/admin/profile-data");
            hideLoader();

            if(response.data['status'] === 'success') {
                const userData = response.data['data'];

                // View user details
                name.value = userData['Name'];
                email.value = userData['Email'];
                password.value = userData['Password'];

                // View profile pic
                const dbImg = userData['Img'];
                const imgPath = "<?php echo e(asset('Uploaded_file/images/users')); ?>" + `/${dbImg}`;
                document.querySelector("#userImg").src = imgPath;
            } else {
                console.log("Oops !");
            }
        }

        async function updateProfile() {
            const name = document.querySelector("#name").value;
            const email = document.querySelector("#email").value;
            const password = document.querySelector("#password").value;

            if(name.length === 0) {
                showTost("Please enter your name");
            } else if(email.length === 0) {
                showTost("Please enter your email address");
            } else if(password.length < 3) {
                showTost("Please enter a strong password minimum 3 cherecter");
            } else {
                showLoader();
                const config = { headers: { 'Content-Type': 'multipart/form-data' } };
                const response = await axios.post("/admin/update-profile", {"name":name, "password":password, config});
                hideLoader();

                if(response.data['status'] === 'success') {
                    showTost(response.data['message']);
                    hidePopUp();
                    userData();
                } else {
                    showTost(response.data['message']);
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Backend.Layouts.Links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Dashboard/Profile.blade.php ENDPATH**/ ?>