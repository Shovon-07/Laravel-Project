<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard</title>
    <link rel="icon" href="<?php echo e(asset('Uploaded_file/images/user.png')); ?>">
    
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/Loader.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/toastify.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/jquery.dataTables.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/sideNav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/summery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/table.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/font_awesome/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/font_awesome/fontawesome.min.css')); ?>" />
</head>

<body>
    <div>
        
        <?php echo $__env->make('Backend.Components.Loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('Backend.Components.SideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="main-panel">
            
            <?php echo $__env->make('Backend.Components.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        

    </div>

    
    <script src="<?php echo e(asset('assets/backend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/axios.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/backend/js/Loader.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/toastify.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/backend/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/popup.js')); ?>"></script>
    
</body>

</html><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Layouts/App.blade.php ENDPATH**/ ?>