<title>Update Password</title>


<?php echo $__env->make('Backend.Components.Loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="form-container">
    <div class="form">
        <h3 class="title">UPDATE PASSWORD</h3>
        <div>
            <input type="password" id="password" placeholder="Enter new password">
        </div>
        <div>
            <input type="password" id="c_password" placeholder="Retype password">
        </div>
        <div class="buttonDiv">
            <button type="submit" class="button" onclick="updatePass()">CONFIRM</button>
        </div>
    </div>
</div>

<script>
    async function updatePass() {
        const email = getSessionData();
        const password = document.querySelector("#password").value;
        const c_password = document.querySelector("#c_password").value;

        if(password.length < 3) {
            showTost("Please enter a strong password minimum 3 cherecter");
        } else if(password.length > 6) {
            showTost("Please enter a strong password maximum 6 cherecter");
        } else if(password !== c_password) {
            showTost("Password not matched");
        } else {
            showLoader();
            const response = await axios.post("/admin/update-password", {"email":email,"password" : password});
            hideLoader();

            if(response.data['status'] === 'success') {
                showTost(response.data['message']);
                
                sessionStorage.clear();
                localStorage.clear();
                
                setTimeout(() => {
                    window.location.href = '/admin/';
                }, 1000);
            } else {
                showTost(response.data['message']);
            }
        }
    }
</script>
<?php echo $__env->make('Backend.Layouts.Links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Auth/UpdatePass.blade.php ENDPATH**/ ?>