<link rel="icon" href="{{asset('Uploaded_file/images/avater.png')}}">

{{-- Css Plugins --}}
{{-- <link rel="stylesheet" href="{{asset('assets/backend/css/bootstrap_css/bootstrap.min.css')}}"> --}}
<link rel="stylesheet" href="{{asset('assets/backend/css/Loader.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/toastify.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/popup.css')}}">
{{-- Css --}}
<link rel="stylesheet" href="{{asset('assets/backend/css/app.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/form.css')}}">
{{-- Font awesome --}}
<link rel="stylesheet" href="{{asset('assets/backend/css/font_awesome/all.min.css')}}" />
<link rel="stylesheet" href="{{asset('assets/backend/css/font_awesome/fontawesome.min.css')}}" />

{{--
    --}}

{{-- Js Plugins --}}
<script src="{{asset('assets/backend/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/backend/js/axios.min.js')}}"></script>
{{-- <script src="{{asset('assets/backend/js/bootstrap_js/bootstrap.min.js')}}"></script> --}}
<script src="{{asset('assets/backend/js/Loader.js')}}"></script>
<script src="{{asset('assets/backend/js/toastify.js')}}"></script>
<script src="{{asset('assets/backend/js/popup.js')}}"></script>

{{-- Script --}}
<script src="{{asset('assets/backend/js/app.js')}}"></script>
<script src="{{asset('assets/backend/js/config.js')}}"></script>