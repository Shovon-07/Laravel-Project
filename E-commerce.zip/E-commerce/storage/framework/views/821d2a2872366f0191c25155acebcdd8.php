<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Mart</title>
    
    <link rel="icon" href="<?php echo e(asset('assets/frontend')); ?>/images/Fav_Icon.png">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/bootstrap_css/bootstrap.min.css">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/sass.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/footer.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/responsive.css">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/font_awesome/all.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/font_awesome/regular.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/font_awesome/fontawesome.css">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0"/>
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/owl_carousel/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend')); ?>/css/owl_carousel/owl.theme.default.min.css">
</head>

<body>
    <div>
        
        

        
        <?php echo $__env->make('Frontend.Components.SideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('Frontend.Components.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="main-panel">            
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <?php echo $__env->make('Frontend.Components.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    
    <script src="<?php echo e(asset('assets/js/axios.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Loader.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastify.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/frontend')); ?>/js/jquery-v3.6.1.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/bootstrap_js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/plugins/owl.carousel.min.js"></script>

    
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/custome.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/custome_jquery.js"></script>
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/carousel.js"></script>
    <script src="<?php echo e(asset('assets/js/popup.js')); ?>"></script>
    
</body>

</html><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Frontend/Layouts/App.blade.php ENDPATH**/ ?>