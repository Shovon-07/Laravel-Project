<?php $__env->startSection('content'); ?>
    <section class="container">
        <?php echo $__env->make('Backend.Components.Summery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Dashboard/Dashboard.blade.php ENDPATH**/ ?>