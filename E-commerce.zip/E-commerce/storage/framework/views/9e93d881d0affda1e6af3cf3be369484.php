<title>Recover Password</title>


<?php echo $__env->make('Backend.Components.Loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="form-container">
    <div class="form">
        <h3 class="title">SEND OTP</h3>
        <div>
            <input type="email" id="email" placeholder="Enter your email address">
        </div>
        <div class="buttonDiv">
            <button type="submit" class="button" onclick="sendOtp()">SEND OTP</button>
        </div>
    </div>
</div>

<script>
    async function sendOtp() {
        const email = document.querySelector("#email").value;
        
        if(email.length === 0) {
            showTost("Please enter email address");
        } else {
            showLoader();
            const response = await axios.post("/admin/send-otp", {'email': email});
            hideLoader();

            if(response.data['status']==='success') {
                showTost(response.data['message']);
                setSessionData(response.data['email']);
                
                setTimeout(() => {
                    window.location.href = "/admin/verify-otp";
                }, 1000);
            } else {
                showTost(response.data['message']);
            }
        }
    }
</script>
<?php echo $__env->make('Backend.Layouts.Links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Auth/RecoverPass.blade.php ENDPATH**/ ?>