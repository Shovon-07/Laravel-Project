<div class="popup hidePopUp" id="categoryCreatePopUp">
    <div>
        <input class="addItemsInput" type="text" id="categoryName" placeholder="Category name">
    </div>
    <button id="closePopUp" onclick="createCategory()">CONFIRM</button>
    <a class="cancel" id="closePopUp" onclick="closePopUp()">Cancel</a>
</div>

<script>
    async function createCategory() {
        const categoryName = $("#categoryName").val();

        if(categoryName.length === 0) {
            showTost("Please enter category name");
        } else {
            showLoader();
            const response = await axios.post("/admin/create-category", {'categoryName':categoryName});
            hideLoader();
            $("#categoryName").val("");
            closePopUp();

            if(response.data['status'] === 'success') {
                showTost(response.data['message']);
                categoryList();
            } else {
                showTost(response.data['message'])
            }
        }
    }
</script><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Components/Categories/CategoryCreate.blade.php ENDPATH**/ ?>