<?php $__env->startSection('content'); ?>
    <section class="container">
        <h2 class="title">Brands</h2>
        <?php echo $__env->make('Backend.Components.Brands.BrandsCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('Backend.Components.Brands.BrandsTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('Backend.Components.Brands.BrandsDelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('Backend.Components.Brands.BrandsEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.Layouts.App', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Pages/Dashboard/BrandsList.blade.php ENDPATH**/ ?>