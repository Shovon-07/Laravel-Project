<div class="summery d-flex">
    <div class="card">
        <i class="fa-solid fa-users"></i>
        <div>
            <h3 class="summeryTitle">Customers</h3>
            <p class="amount">2000</p>
        </div>
    </div>
    <div class="card">
        <i class="fa-solid fa-truck-fast leftIcon"></i>
        <div>
            <h3 class="summeryTitle">Orders</h3>
            <p class="amount">305</p>
        </div>
    </div>
    <div class="card">
        <i class="fa-solid fa-dollar-sign"></i>
        <div>
            <h3 class="summeryTitle">Balance</h3>
            <p class="amount">1000K</p>
        </div>
    </div>
</div><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Components/Summery.blade.php ENDPATH**/ ?>