<div class="popup hidePopUp">
    <div>
        <h3 style="margin-bottom:20px">Change profile pic</h3>
    </div>
    <div>
        <input type="file" id="updateProfilePic" placeholder="Choose profile pic">
    </div>
    <button onclick="updatePic()" id="closePopUp">CONFIRM</button>
    <a class="cancel" id="closePopUp">Cancel</a>
</div>

<script>
    // async function updatePic() {
    //     const updateProfilePic = document.querySelector("#updateProfilePic").value;
        
    //     showLoader();
    //     const response = await axios.post("/admin/update-profile",{
    //         "Img": updateProfilePic
    //     });
    //     hideLoader();
    // }
</script><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Components/Popup.blade.php ENDPATH**/ ?>