<link rel="icon" href="<?php echo e(asset('Uploaded_file/images/avater.png')); ?>">



<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/Loader.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/toastify.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/popup.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/form.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/font_awesome/all.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/font_awesome/fontawesome.min.css')); ?>" />




<script src="<?php echo e(asset('assets/backend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/axios.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/backend/js/Loader.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/toastify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/popup.js')); ?>"></script>


<script src="<?php echo e(asset('assets/backend/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/config.js')); ?>"></script><?php /**PATH /home/shovon/Documents/Web-Development/Backend-Projects/Laravel-Project/E-commerce/resources/views/Backend/Layouts/Links.blade.php ENDPATH**/ ?>